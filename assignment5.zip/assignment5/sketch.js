let value = 1;
let fr = 30;
let off = 0;
let light = false;
let spot = 270;
function setup() {
  // put setup code here
  createCanvas(900, 600);
  
  background('#CC8E6C');
  
	frameRate(fr);
}

function draw() {
	ellipseMode(RADIUS);
	colorMode(RGB, 255, 255, 255, 1);
	background('#CC8E6C');
	fill('#FFBB78');
	noStroke();
	rect(0, 450, 900, 150);
	fill('#616099');
	rect(250, 170, 400, 230);
	rect(350, 400, 200, 100);
	fill('#807ECC');
	rect(270, 190, 360, 190);
	rect (270, 385, 25, 10);
	fill('#FFBB78');
	ellipse(620,390,8,8);
	fill('#B8DCFF');
	if(light == true)
	{
		fill('#FFBB78');
	}
	rect(375,425,150,50);
	if(off == 0)
	{	
		if(value == 0)
		{
		fill('#CC8E6C');
		}
		else
		{
		fill('#B8DCFF');
		}
		spot = spot + 4;
		if(spot >= 580)
		{
		spot = 270;
		}
	rect(spot, 290, 50, 90);
	}
	frameRate(fr);
}
function mouseClicked() {
	if(mouseX >= 270 && mouseX <= 295 && mouseY >= 385 && mouseY <= 395 )
	{
	if(off != 1)
	{
	if (value === 0)
	{
    value = 1;
	} 	
	else 
		{
		value = 0;
		}
	}
	}
	else if(sq(mouseX-620) + sq(mouseY-390) <= 64)
	{
		if(off == 0)
		{	
		off = 1;
		}
		else
		{
		off =0;
		}
	}
}
function keyPressed() 
{
	if(mouseX >= 375 && mouseX <= 525 && mouseY >= 425 && mouseY <= 475 && keyCode == 65)
	{
		if(light == true)
		{
			light = false;
		}
		else
		{
			light = true;
		}
	}
		
}