var spooks = [];
function setup() {
	createCanvas(900, 600);
	background(0);
	noStroke();
	spooks[0] = new ghosts(mouseX,mouseY,0);
	
	for(var i = 1; i < 30; i++)
	{
		spooks[i] = new ghosts(random(100, 800), random(100,500), i);
	}
	print(spooks.length);
}
function draw() {
	fill(0);
	rect(0,0,900,600);
	for(var i = 0; i < spooks.length - 1; i++)
	{
		spooks[i].move();
		fill(255);
		spooks[i].display();
	}
    
    
}
function ghosts(xHere, yHere,placement)
{
	var nowX = xHere;
	var nowY = yHere;
	this.move = function()
	{
		
		fill(0);
		if(placement!=0)
		{
		
		nowY-=4;
			if(nowY < -50)
			{
				nowY = 650;
			}
		}
		else
		{
			push();
			translate(pmouseX,pmouseY)
			{
			ellipseMode(RADIUS);
			ellipse(0,0,15,15);
			rect(-15,0,30,40);
			ellipse(0,5,25,10);	
			}
			pop();
		}
		
	}
	this.display = function () 
    {
		push();
		if(placement != 0)
		{
			translate(nowX, nowY);
			
		}
		else
		{
			translate(mouseX, mouseY);
			
		}
		ellipseMode(RADIUS);
			ellipse(0,0,15,15);
			rect(-15,0,30,40);
			ellipse(0,5,25,10);	
		
		pop();
		
	};
}	
	