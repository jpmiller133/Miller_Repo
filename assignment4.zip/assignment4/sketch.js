
let rectX = 0;
let offomode = 0;
let fr = 45;
let red = 0;
let green = 0;
let blue = 0;
function setup() {
  // put setup code here
  createCanvas(600, 600);
  
  background(125);
  colorMode(RGB, 255, 255, 255, 1);
  frameRate(fr);
}

function draw() {
	background(125);
	blue == 0;
	while(blue < green - 4 && offomode == 0)
	{
		blue = blue + 4;
	}
	fill(red, green, blue);
	if(keyIsPressed == true)
	{
		green = red/2;
	}
	if(rectX >= 550 && offomode == 0)
	{	
		offomode = 1;
	}
	else if(rectX <= 0 && offomode == 1)
	{
		offomode = 0
	}
	
	if(offomode == 0)
	{	
	rectX = rectX += 2;
	}
	if(offomode == 1)
	{	
	rectX = rectX -= 2;
	}
	rect(rectX, 50, 50, 50);
	frameRate(fr);
	}
	function mouseClicked()
	{
		red = red += 25;
		if(red >= 255)
		{
		red = 0;
		}
	}		
	
	

